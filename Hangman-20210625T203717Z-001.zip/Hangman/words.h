#ifndef WORDS_H_INCLUDED
#define WORDS_H_INCLUDED

void dictionary(char (&chosenWord)[5], int choice);

#endif // WORDS_H_INCLUDED
